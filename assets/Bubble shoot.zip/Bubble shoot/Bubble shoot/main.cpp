#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include <time.h>

#define SCREEN_W 800
#define SCREEN_H 600
#define BALL_SIZE 25
#define PI 3.14159
#define DEATH_LINE 500

struct Ball {
    bool isAlive;
    int color;
    float x, y;
};

Ball grid[12][15];
bool visited[12][15];
bool attached[12][15];

float playerX, playerY;
float playerSpeedX, playerSpeedY;
int playerColor;
int nextBallColor;
bool isShooting = false;
float aimAngle = 90;

int score = 0;
int level = 1;
bool gameOver = false;
bool youWon = false;

float ceilingY = 0;
float ceilingSpeed = 5.5;
int ballsShot = 0;
bool isPowerBall = false;
bool nextIsPowerBall = false;
int gameTimer = 0;

GLuint backgroundTexture;

unsigned char* loadBMP(const char* filename, int* width, int* height) {
    FILE* file = fopen(filename, "rb");
    if (!file) {
        printf("Error: Cannot open file %s\n", filename);
        return NULL;
    }

    unsigned char header[54];
    fread(header, sizeof(unsigned char), 54, file);

    *width = *(int*)&header[18];
    *height = *(int*)&header[22];

    int size = (*width) * (*height) * 3;
    unsigned char* data = (unsigned char*)malloc(size);
    fread(data, sizeof(unsigned char), size, file);
    fclose(file);

    for (int i = 0; i < size; i += 3) {
        unsigned char temp = data[i];
        data[i] = data[i + 2];
        data[i + 2] = temp;
    }

    return data;
}

void loadBackgroundTexture() {
    int width, height;
    unsigned char* image = loadBMP("background.bmp", &width, &height);

    if (!image) {
        printf("Failed to load background image!\n");
        return;
    }

    glGenTextures(1, &backgroundTexture);
    glBindTexture(GL_TEXTURE_2D, backgroundTexture);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

    free(image);
}

void drawBackground() {
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, backgroundTexture);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glColor4f(1.0, 1.0, 1.0, 1.0);

    glBegin(GL_QUADS);
        glTexCoord2f(0.0, 1.0); glVertex2f(0, 0);
        glTexCoord2f(1.0, 1.0); glVertex2f(SCREEN_W, 0);
        glTexCoord2f(1.0, 0.0); glVertex2f(SCREEN_W, SCREEN_H);
        glTexCoord2f(0.0, 0.0); glVertex2f(0, SCREEN_H);
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glBegin(GL_QUADS);
        glColor4f(0.0, 0.0, 0.1, 0.3);
        glVertex2f(0, 0);
        glVertex2f(SCREEN_W, 0);
        glColor4f(0.0, 0.0, 0.0, 0.0);
        glVertex2f(SCREEN_W, SCREEN_H);
        glVertex2f(0, SCREEN_H);
    glEnd();

    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
}

void setupLighting() {
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);


    GLfloat light0_ambient[] = { 0.3, 0.3, 0.3, 1.0 };
    GLfloat light0_diffuse[] = { 0.9, 0.9, 0.9, 1.0 };
    GLfloat light0_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat light0_position[] = { SCREEN_W/2, -100, 500.0, 1.0 };

    glLightfv(GL_LIGHT0, GL_AMBIENT, light0_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light0_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light0_position);


    GLfloat light1_ambient[] = { 0.2, 0.2, 0.2, 1.0 };
    GLfloat light1_diffuse[] = { 0.5, 0.5, 0.5, 1.0 };
    GLfloat light1_specular[] = { 0.3, 0.3, 0.3, 1.0 };
    GLfloat light1_position[] = { -200, SCREEN_H/2, 300.0, 1.0 };

    glLightfv(GL_LIGHT1, GL_AMBIENT, light1_ambient);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light1_diffuse);
    glLightfv(GL_LIGHT1, GL_SPECULAR, light1_specular);
    glLightfv(GL_LIGHT1, GL_POSITION, light1_position);


    GLfloat mat_specular[] = { 0.8, 0.8, 0.8, 1.0 };
    GLfloat mat_shininess[] = { 100.0 };

    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);

    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_NORMALIZE);
}

void drawSphere(float x, float y, int colorID) {
    glPushMatrix();
    glTranslatef(x, y, 0);


    if (colorID == 0) glColor3f(0.8, 0.1, 0.1);
    else if (colorID == 1) glColor3f(0.1, 0.3, 0.8);
    else if (colorID == 2) glColor3f(0.1, 0.8, 0.3);
    else if (colorID == 3) glColor3f(0.9, 0.7, 0.1);
    else if (colorID == 4) glColor3f(0.8, 0.2, 0.8);
    else if (colorID == 99) glColor3f(0.15, 0.15, 0.15);
    else glColor3f(0.8, 0.8, 0.8);


    GLfloat mat_specular[] = { 0.9, 0.9, 0.9, 1.0 };
    GLfloat mat_shininess[] = { 128.0 };

    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);


    glutSolidSphere(BALL_SIZE, 32, 32);
    glPopMatrix();
}

void drawShooterNet(float x, float y) {
    glDisable(GL_LIGHTING);
    glColor3f(0.9, 0.9, 1.0);
    glLineWidth(2.5);

    glPushMatrix();
    glTranslatef(x, y, 0);

    glBegin(GL_LINE_LOOP);
    for(int i = 0; i < 36; i++) {
        float angle = i * 10.0 * PI / 180.0;
        glVertex3f(cos(angle) * 35, sin(angle) * 35, 0);
    }
    glEnd();

    glBegin(GL_LINES);
    glVertex3f(-30, -30, 0); glVertex3f(30, 30, 0);
    glVertex3f(-30, 30, 0); glVertex3f(30, -30, 0);
    glVertex3f(0, -35, 0); glVertex3f(0, 35, 0);
    glVertex3f(-35, 0, 0); glVertex3f(35, 0, 0);
    glEnd();

    glPopMatrix();
    glLineWidth(1.0);
    glEnable(GL_LIGHTING);
}

void drawText(float x, float y, char *text) {
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, SCREEN_W, SCREEN_H, 0);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glColor3f(1.0, 1.0, 1.0);
    glRasterPos2f(x, y);
    for (int i = 0; text[i] != '\0'; i++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text[i]);
    }

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

    glEnable(GL_LIGHTING);
    glEnable(GL_DEPTH_TEST);
}

void drawDeadLine() {
    glDisable(GL_LIGHTING);
    glColor3f(1.0, 0.2, 0.2);
    glLineWidth(4.0);

    glBegin(GL_LINES);
    glVertex3f(0, DEATH_LINE, 0);
    glVertex3f(SCREEN_W, DEATH_LINE, 0);
    glEnd();

    glLineWidth(2.0);
    for(int i = 0; i < SCREEN_W; i += 20) {
        glBegin(GL_LINES);
        glVertex3f(i, DEATH_LINE - 3, 0);
        glVertex3f(i + 10, DEATH_LINE - 3, 0);
        glEnd();
    }

    glLineWidth(1.0);
    glEnable(GL_LIGHTING);
}

void drawCeiling() {
    glDisable(GL_LIGHTING);
    glColor3f(0.4, 0.4, 0.5);
    glLineWidth(5.0);
    glBegin(GL_LINES);
    glVertex3f(0, ceilingY, 0);
    glVertex3f(SCREEN_W, ceilingY, 0);
    glEnd();

    glLineWidth(3.0);
    for(int i = 0; i < SCREEN_W; i += 40) {
        glBegin(GL_LINES);
        glVertex3f(i, ceilingY, 0);
        glVertex3f(i, ceilingY + 15, 0);
        glEnd();
    }

    glLineWidth(1.0);
    glEnable(GL_LIGHTING);
}

void drawAimLine() {
    glDisable(GL_LIGHTING);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glColor4f(1.0, 1.0, 1.0, 0.8);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glVertex3f(playerX, playerY, 0);
    glVertex3f(playerX + cos(aimAngle * PI/180) * 120,
               playerY - sin(aimAngle * PI/180) * 120, 0);
    glEnd();

    glDisable(GL_BLEND);
    glLineWidth(1.0);
    glEnable(GL_LIGHTING);
}

int getSmartBallColor(int colorRange) {
    int colorCounts[5] = {0, 0, 0, 0, 0};

    for(int i = 0; i < 12; i++) {
        for(int j = 0; j < 15; j++) {
            if(grid[i][j].isAlive && grid[i][j].color < 5) {
                colorCounts[grid[i][j].color]++;
            }
        }
    }

    int maxCount = 0;
    int mostFrequentColor = 0;
    for(int i = 0; i < colorRange; i++) {
        if(colorCounts[i] > maxCount) {
            maxCount = colorCounts[i];
            mostFrequentColor = i;
        }
    }

    if(maxCount == 0) {
        return rand() % colorRange;
    }

    return mostFrequentColor;
}

void generateNextBall(int colorRange) {
    int randValue = rand() % 100;

    if(randValue < 15) {
        nextIsPowerBall = true;
        nextBallColor = 99;
    } else {
        nextIsPowerBall = false;
        nextBallColor = getSmartBallColor(colorRange);
    }
}

void startLevel(int lvl) {
    level = lvl;
    if (level > 3) {
        youWon = true;
        return;
    }

    playerX = SCREEN_W / 2;
    playerY = SCREEN_H - 50;
    isShooting = false;
    gameOver = false;
    ceilingY = 0;
    gameTimer = 0;
    ballsShot = 0;
    isPowerBall = false;
    nextIsPowerBall = false;

    int colorCount = 3;
    if (level == 2) colorCount = 4;
    if (level == 3) colorCount = 5;

    for(int i=0; i<12; i++) {
        for(int j=0; j<15; j++) grid[i][j].isAlive = false;
    }

    int rowsToFill = level + 2;
    for(int i=0; i<rowsToFill; i++) {
        for(int j=0; j<15; j++) {
            grid[i][j].isAlive = true;
            grid[i][j].color = rand() % colorCount;
            grid[i][j].x = j * 50 + 25 + (i % 2) * 25;
            grid[i][j].y = i * 45 + 25;
        }
    }

    playerColor = getSmartBallColor(colorCount);
    generateNextBall(colorCount);
}

void findMatches(int r, int c, int targetColor) {
    if (r < 0 || r >= 12 || c < 0 || c >= 15) return;
    if (!grid[r][c].isAlive || visited[r][c] || grid[r][c].color != targetColor) return;
    visited[r][c] = true;
    findMatches(r-1, c, targetColor);
    findMatches(r+1, c, targetColor);
    findMatches(r, c-1, targetColor);
    findMatches(r, c+1, targetColor);
    if (r % 2 == 0) {
        findMatches(r-1, c-1, targetColor);
        findMatches(r+1, c-1, targetColor);
    } else {
        findMatches(r-1, c+1, targetColor);
        findMatches(r+1, c+1, targetColor);
    }
}

void findSupport(int r, int c) {
    if (r < 0 || r >= 12 || c < 0 || c >= 15) return;
    if (!grid[r][c].isAlive || attached[r][c]) return;
    attached[r][c] = true;
    findSupport(r-1, c);
    findSupport(r+1, c);
    findSupport(r, c-1);
    findSupport(r, c+1);
    if (r % 2 == 0) {
        findSupport(r-1, c-1);
        findSupport(r+1, c-1);
    } else {
        findSupport(r-1, c+1);
        findSupport(r+1, c+1);
    }
}

void dropHangingBubbles() {
    for(int i=0; i<12; i++) for(int j=0; j<15; j++) attached[i][j] = false;
    for(int j=0; j<15; j++) if(grid[0][j].isAlive) findSupport(0, j);
    for(int i=0; i<12; i++) {
        for(int j=0; j<15; j++) {
            if(grid[i][j].isAlive && !attached[i][j]) {
                grid[i][j].isAlive = false;
                score += 5;
            }
        }
    }
}

void explodeArea(int r, int c, int radius) {
    for(int i = r - radius; i <= r + radius; i++) {
        for(int j = c - radius; j <= c + radius; j++) {
            if(i >= 0 && i < 12 && j >= 0 && j < 15) {
                if(grid[i][j].isAlive) {
                    grid[i][j].isAlive = false;
                    score += 15;
                }
            }
        }
    }
}

void stickBallToGrid() {
    int bestRow = 0; int bestCol = 0;
    float closestDist = 10000.0;

    for(int i=0; i<12; i++) {
        for(int j=0; j<15; j++) {
            float spotX = j * 50 + 25 + (i % 2) * 25;
            float spotY = i * 45 + 25 + ceilingY;
            float dx = playerX - spotX; float dy = playerY - spotY;
            float dist = sqrt(dx*dx + dy*dy);
            if (dist < closestDist && !grid[i][j].isAlive) {
                closestDist = dist; bestRow = i; bestCol = j;
            }
        }
    }

    if(isPowerBall) {
        explodeArea(bestRow, bestCol, 2);
        dropHangingBubbles();
        isPowerBall = false;
    } else {
        grid[bestRow][bestCol].isAlive = true;
        grid[bestRow][bestCol].color = playerColor;
        grid[bestRow][bestCol].x = bestCol * 50 + 25 + (bestRow % 2) * 25;
        grid[bestRow][bestCol].y = bestRow * 45 + 25 + ceilingY;

        for(int i=0; i<12; i++) for(int j=0; j<15; j++) visited[i][j] = false;
        findMatches(bestRow, bestCol, playerColor);

        int count = 0;
        for(int i=0; i<12; i++) for(int j=0; j<15; j++) if(visited[i][j]) count++;

        if (count >= 3) {
            for(int i=0; i<12; i++) for(int j=0; j<15; j++)
                if(visited[i][j]) { grid[i][j].isAlive = false; score += 10; }
            dropHangingBubbles();
        }
    }

    bool ballsLeft = false;
    for(int i=0; i<12; i++) {
        for(int j=0; j<15; j++) {
            if(grid[i][j].isAlive) {
                ballsLeft = true;
                if(grid[i][j].y >= DEATH_LINE) {
                    gameOver = true;
                }
            }
        }
    }

    if (!ballsLeft) {
        startLevel(level + 1);
        return;
    }

    isShooting = false;
    ballsShot++;
    playerX = SCREEN_W / 2; playerY = SCREEN_H - 50;

    int colorRange = 3;
    if (level == 2) colorRange = 4;
    if (level == 3) colorRange = 5;

    playerColor = nextBallColor;
    isPowerBall = nextIsPowerBall;

    generateNextBall(colorRange);
}

void updateGame() {
    if (!gameOver && !youWon) {
        ceilingY += ceilingSpeed / 60.0;

        if(ceilingY >= DEATH_LINE) {
            gameOver = true;
        }

        for(int i=0; i<12; i++) {
            for(int j=0; j<15; j++) {
                if(grid[i][j].isAlive) {
                    grid[i][j].y += ceilingSpeed / 60.0;
                    if(grid[i][j].y >= DEATH_LINE) {
                        gameOver = true;
                    }
                }
            }
        }
    }

    if (isShooting && !gameOver && !youWon) {
        playerX += playerSpeedX;
        playerY += playerSpeedY;
        if (playerX < 25 || playerX > SCREEN_W - 25) playerSpeedX = -playerSpeedX;
        if (playerY < 25 + ceilingY) { stickBallToGrid(); return; }
        for(int i=0; i<12; i++) {
            for(int j=0; j<15; j++) {
                if (grid[i][j].isAlive) {
                    float dx = playerX - grid[i][j].x; float dy = playerY - grid[i][j].y;
                    if (sqrt(dx*dx + dy*dy) < 45) { stickBallToGrid(); return; }
                }
            }
        }
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    drawBackground();

    drawCeiling();
    drawDeadLine();

    for(int i=0; i<12; i++) {
        for(int j=0; j<15; j++) {
            if (grid[i][j].isAlive) {
                drawSphere(grid[i][j].x, grid[i][j].y, grid[i][j].color);
            }
        }
    }

    if (!isShooting && !gameOver && !youWon) {
        drawAimLine();
        drawShooterNet(playerX, playerY);

        drawSphere(playerX - 70, playerY, nextBallColor);
    }

    if (!youWon) {
        drawSphere(playerX, playerY, playerColor);
    }

    char scoreText[80];
    sprintf(scoreText, "Score: %d  Level: %d", score, level);
    drawText(10, SCREEN_H - 20, scoreText);

    if(isPowerBall && !isShooting) {
        glDisable(GL_LIGHTING);
        glColor3f(1.0, 1.0, 0.0);
        drawText(300, 560, "POWER BALL!");
        glEnable(GL_LIGHTING);
    }

    if (gameOver) {
        glDisable(GL_LIGHTING);
        glColor3f(1.0, 0.3, 0.3);
        drawText(280, 300, "GAME OVER (Press R)");
        glEnable(GL_LIGHTING);
    }
    if (youWon) {
        glDisable(GL_LIGHTING);
        glColor3f(0.3, 1.0, 0.5);
        drawText(240, 300, "VICTORY! ALL LEVELS CLEAR!");
        glEnable(GL_LIGHTING);
    }

    glutSwapBuffers();
}

void mouseClick(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && !isShooting && !gameOver && !youWon) {
        isShooting = true;
        playerSpeedX = cos(aimAngle * PI/180) * 8.0;
        playerSpeedY = -sin(aimAngle * PI/180) * 8.0;
    }
}

void mouseMove(int x, int y) {
    if (!isShooting) {
        aimAngle = atan2(playerY - y, x - playerX) * 180 / PI;
        if (aimAngle < 15) aimAngle = 15;
        if (aimAngle > 165) aimAngle = 165;
    }
}

void keyboard(unsigned char key, int x, int y) {
    if (key == 'r' || key == 'R') {
        score = 0;
        startLevel(1);
    }
    if (key == 27) exit(0);
}

void timer(int v) {
    updateGame();
    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(SCREEN_W, SCREEN_H);
    glutCreateWindow("Bubble Shooter");

    glClearColor(0.0, 0.0, 0.0, 1.0);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, SCREEN_W, SCREEN_H, 0, -500, 500);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    setupLighting();
    loadBackgroundTexture();

    srand(time(NULL));
    startLevel(1);

    glutDisplayFunc(display);
    glutMouseFunc(mouseClick);
    glutPassiveMotionFunc(mouseMove);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(0, timer, 0);
    glutMainLoop();
    return 0;
}
